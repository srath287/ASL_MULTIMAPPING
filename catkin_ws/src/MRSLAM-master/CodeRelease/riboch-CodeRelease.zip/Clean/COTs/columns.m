function nc = columns(A)
% returns the number of columns in matrix A

nc = size(A,2);

end
